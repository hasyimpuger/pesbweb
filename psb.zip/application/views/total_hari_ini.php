<div class="panel panel-success">
	<div class="panel-heading">
		<div class="row">
			<div class="col-xs-3">
				<i class="fa fa-calendar-check-o fa-5x"></i>
			</div>
			<div class="col-xs-9 text-right">
				<div class="huge"><?php echo $isi->num_rows(); ?></div>
				<div>Pendaftar Hari Ini</div>
			</div>
		</div>
	</div>
	<a href="#">
		<div class="panel-footer">
			<span class="pull-left"></span>
			<span class="pull-right"><i class="fa fa-arrow-circle-down"></i></span>
			<div class="clearfix"></div>
		</div>
	</a>
</div>