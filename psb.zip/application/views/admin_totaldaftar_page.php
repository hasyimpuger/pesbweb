<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
	<style type="text/css">
	.sambutan {
		margin-bottom: 40px;
		font-weight: bolder;
	}
	.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
		padding: 5px;
		font-size: 11px;
	}
	</style>
	
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>                        
				</button>
				<a class="navbar-brand" href="#">Halaman Admin PSB Online SMAN 05</a>
			</div>
			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav navbar-right">
					<li><a href="#"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
				</ul>
			</div>
		</div>
	</nav>

	<div class="container-fluid">
		<table class="table table-hover table-bordered">
			<caption><strong>Data seluruh pendaftar hingga tanggal <?php print date('d-m-Y'); ?> (sebagian data tidak dapat ditampilkan) :</strong></caption>
			<thead>
				<tr>
					<th>No.</th>
					<th>Nama Lengkap</th>
					<th>Kelamin</th>
					<th>Agama</th>
					<th>SMP Asal</th>
					<th>Alamat SMP</th>
					<th>total UN</th>
					<th>Hp/Telpon</th>
					<th>ID Terdaftar</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$no=1;
				foreach ($data->result() as $row) { 
					?>
					<tr>
						<td><?php echo $no++; ?></td>
						<td><?php echo $row->nama; ?></td>
						<td><?php echo $row->kelamin; ?></td>
						<td><?php echo $row->agama; ?></td>
						<td><?php echo $row->smp_asal; ?></td>
						<td><?php echo $row->alamat_smp; ?></td>
						<td><?php echo $row->un_total; ?></td>
						<td><?php echo $row->telpon; ?></td>
						<td><?php echo $row->id; ?></td>
					</tr>
				</tbody>
				<?php } ?>
			</table><br>
			<button type="button" class="btn btn-default btn-sm">Simpan Database <i class="fa fa fa-database"></i></button>
		</div>
	</body>